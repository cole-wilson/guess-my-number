# Guess My Number
A guess my number game.


### Installation
**Install with Pip:** `pip3 install guess-my-number`

### Usage:
Run `guess-my-number` in your terminal.
### Contributors
 - Cole Wilson
### Contact
<cole@colewilson.xyz>